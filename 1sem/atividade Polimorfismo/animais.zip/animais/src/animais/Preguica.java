package animais;
public class Preguica extends Animal{
    
    
    @Override
    public void emitirSom(){
        System.out.println("uuuhhhááaaããã");
    }
    
    public void escalar(){
        System.out.println("A Pegriça está subindo na arvore");
    }
}
