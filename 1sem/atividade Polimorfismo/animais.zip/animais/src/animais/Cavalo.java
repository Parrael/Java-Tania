package animais;
public class Cavalo extends Animal{
    
    @Override
    public void emitirSom(){
        System.out.println("relincho");
        
    }
    
    public void correr(){
        System.out.println("O cavalo está correndo");
    }
}
